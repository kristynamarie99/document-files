using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace JQueryMenu
{
    public partial class Default : System.Web.UI.Page
    {
        List<XmlNode> listXmlNode = new List<XmlNode>();
        List<XmlNode> listXmlTopParentNode = new List<XmlNode>();
        string structure = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //RenderLeftMenu(category1.ID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void lbtCategory_Click(object sender, EventArgs e)
        {
            RenderLeftMenu((sender as LinkButton).ID);
        }

        private void RenderLeftMenu(string categoryName)
        {
            XmlDocument tblTestXml = new XmlDocument();
            tblTestXml.Load(Server.MapPath("Menu.xml"));
            XmlNode root = tblTestXml.FirstChild;

            foreach (XmlNode item in root.ChildNodes)
            {
                listXmlNode.Add(item);
                if (item.Attributes.GetNamedItem("ParentMenuID").Value == "0" && item.Attributes.GetNamedItem("Category").Value == categoryName)
                {
                    listXmlTopParentNode.Add(item);
                }
            }

            foreach (XmlNode item in listXmlTopParentNode)
            {
                CreatedMenuStructure(item, 0);
            }

            renderLeftMenu.Text = "<ul class=\"leftmenu\">" + structure + "</ul>";
        }

        private void CreatedMenuStructure(XmlNode item, int padding)
        {
            if (item.Attributes.GetNamedItem("ParentMenuID").Value == "0")
            {
                structure += "<li id=\"" + item.Attributes.GetNamedItem("Id").Value + "\" class=\"parent\">";
            }
            else
            {
                structure += "<li id=\"" + item.Attributes.GetNamedItem("Id").Value + "\">";
            }
            structure += "<a style=\"padding-left:" + padding.ToString() + "px\" href=\"" + item.Attributes.GetNamedItem("URL").Value + "\">";
            // Add expand Icon for submenu
            structure += "<table><tr><td style=\"width:20px\">";
            if (HasChild(item) && item.Attributes.GetNamedItem("ParentMenuID").Value != "0")
            {
                structure += "<img style=\"border-style:none\" class=\"expandImage\" alt=\"expand\" src=\"expand.png\" title=\"Expand\" />";
            }
            structure += "</td><td>";
            structure +=  item.Attributes.GetNamedItem("Description").Value + "</td></table></a>";

            // Add child menu for current menu
            if (HasChild(item))
            {
                structure += "<ul>";
                string id = item.Attributes.GetNamedItem("Id").Value;
                foreach (XmlNode childItem in listXmlNode)
                {
                    if (childItem.Attributes.GetNamedItem("ParentMenuID").Value == id)
                    {
                        CreatedMenuStructure(childItem, padding + 10);
                    }
                }
                structure += "</ul>";
            }
            structure += "</li>";
        }

        private bool HasChild(XmlNode currentXmlNote)
        {
            string id = currentXmlNote.Attributes.GetNamedItem("Id").Value;
            foreach (XmlNode item in listXmlNode)
            {
                if (item.Attributes.GetNamedItem("ParentMenuID").Value == id)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
